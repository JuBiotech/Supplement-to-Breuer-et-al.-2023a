.. _examples:

Examples
========

.. toctree::
   :maxdepth: 2

   reaction_cstr
   rtd
   batch_chromatography
   load_wash_elute
