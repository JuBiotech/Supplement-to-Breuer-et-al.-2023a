Residence time distributions
============================

